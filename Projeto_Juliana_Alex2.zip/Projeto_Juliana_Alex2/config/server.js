let express = require('express'); //Express é uma biblioteca que controla as rotas da aplicação
let app = express();
let cors = require('cors');

//const expressLayout = require('express-ejs-layouts');

//app.set('view engine', 'html'); //Configurando o EJS como visualizador padrão

app.use(cors());
app.use(express.static('views/static')); // Configurando o Express para arquivos estáticos
app.use(express.json()); //Configurando o Express para trabalhar com json
app.use(express.urlencoded({extend: true})); //Config o Express para receber formulários Html como json


module.exports = app;