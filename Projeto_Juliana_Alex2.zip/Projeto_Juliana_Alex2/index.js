const db = require('./config/dbConnection');
let app = require('./config/server'); //Importa o servidor Express configurado anteriormente 
//MarceloLedo 
let rotaFuncionario = require('./model/routeFuncionario');
rotaFuncionario.adiciona(app);
rotaFuncionario.lista(app);
rotaFuncionario.altera(app);
rotaFuncionario.buscaPorId(app);


let rotaServicos = require('./model/routeServicos');
rotaServicos.renderServicos(app);

let rotaSolicitacoes = require('./model/routeSolicitacoes');
rotaSolicitacoes.renderSolicitacoes(app);

app.listen(8000, function(){ //Configurando a porta que o servidor vai funcionar
    console.log("Servidor iniciado na porta 8000");
});
